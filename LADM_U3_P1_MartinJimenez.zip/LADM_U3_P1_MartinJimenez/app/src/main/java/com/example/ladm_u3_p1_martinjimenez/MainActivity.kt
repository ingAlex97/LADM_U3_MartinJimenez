package com.example.ladm_u3_p1_martinjimenez

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setTitle("Captura de Actividades")
        imagenE.setOnClickListener {
            cargarImagen()
        }
        var descripcion = txtDescripcion.text.toString()
        var fechaCaptura = txtFechaCaptura.text.toString()
        var fechaEntrega = txtFechaEntrega.text.toString()

        btnCapturar.setOnClickListener{
            var a = Actividad(descripcion,fechaCaptura,fechaEntrega)
            a.asignarPuntero(this)
            if(a.insertar()){
                mensaje("Se inserto correctamente")
                txtDescripcion.setText("")
                txtFechaCaptura.setText("")
                txtFechaEntrega.setText("")
            }else{
                dialogo("!ERROR¡ No se pudo insertar")
            }
        }

        btnCapturarImagen.setOnClickListener {

        }

        btnBuscar.setOnClickListener{
            var ventana = Intent(this,Main2Activity::class.java)
            startActivity(ventana)

            /*
             intento.putExtra("nombre",t.nombre)
             intento.putExtra("puesto",t.puesto)
             intento.putExtra("sueldo",t.sueldo)
             intento.putExtra("id",t.id)*/
        }
    }

    private fun cargarImagen() {
        var intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.setType("image/*")
        startActivityForResult(intent, 10)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(resultCode == Activity.RESULT_OK){
            var path = data?.data
           imagenE.setImageURI(path)
        }
    }

    fun mensaje(s:String){
        Toast.makeText(this,s, Toast.LENGTH_LONG).show()
    }

    fun dialogo(s:String){
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("ATENCION")
            .setMessage(s)
            .setPositiveButton("ok"){d,i->}.show()
    }


}
