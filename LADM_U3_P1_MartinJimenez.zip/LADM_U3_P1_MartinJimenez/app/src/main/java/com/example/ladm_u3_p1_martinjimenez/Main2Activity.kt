package com.example.ladm_u3_p1_martinjimenez

import android.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_main.btnBuscar
import kotlinx.android.synthetic.main.activity_main2.*

class Main2Activity : AppCompatActivity() {
    var listaID = ArrayList<Int>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        cargarLista()


        btnBuscar.setOnClickListener {
            if(txtIdBuscar.text.toString().isEmpty()){
                cargarLista()
            }else{
                buscarActividad()
            }


        }//buscar por ID


        button.setOnClickListener{
            finish()
        }
    }//onCreate

    fun buscarActividad(){
        var clave = txtIdBuscar.text.toString()
        var act = Actividad("","","")
        act.asignarPuntero(this)
        var actE=act.buscar(clave)

        var cadena = "id: "+actE.id+"\n"+"Descripcion:"+actE.descripcion+"\n"+"Fecha captura:"+actE.fechaCaptura+"\n"+"Fecha Entrega:"+actE.fechaEntrega

        var arreglo = ArrayList<String>()
        arreglo.add(cadena)

        listaTareas.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arreglo)

        listaTareas.setOnItemClickListener { parent, view, position, id ->
            AlertDialog.Builder(this)
                .setTitle("Atencion")
                .setMessage("¿qué desea hacer con la actividad ${actE.id}?")
                .setPositiveButton("Borrar"){d,i->
                    //eliminar(listaID[actE.id])
                }
                .setNeutralButton("Agregar imagen"){d,i->}
                .setNegativeButton("Cancelar"){d,i->}
                .show()

        }
    }

    fun cargarLista(){
        var act = Actividad("","","")
        act.asignarPuntero(this)
        var arreglo = act.mostrarTodos()
        var arreglo2 = ArrayList<String>()
        listaID = ArrayList<Int>()
        (0..arreglo.size-1).forEach{
            var cadena = "id: "+arreglo[it].id+"\n"+"Descripcion:"+arreglo[it].descripcion+"\n"+"Fecha captura:"+arreglo[it].fechaCaptura+"\n"+"Fecha Entrega:"+arreglo[it].fechaEntrega
            arreglo2.add(cadena)
            listaID.add(arreglo[it].id)
        }
        listaTareas.adapter = ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,arreglo2)

        listaTareas.setOnItemClickListener { parent, view, position, id ->

            AlertDialog.Builder(this)
                .setTitle("Eliminar actividad")
                .setMessage("¿Desea eliminar la actividad ${arreglo[position].id}?")
                .setPositiveButton("si eliminar"){d,i->
                    //eliminar(listaID[position],root)
                    }//eliminarActividad
                .setNegativeButton("Cancelar"){d,i->}
                .show()

        }
    }
}
